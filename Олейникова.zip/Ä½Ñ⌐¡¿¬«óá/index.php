<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ОТКРЫТИЕ-ГЛАВНАЯ</title>
    <link rel="stylesheet" href="./style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Comfortaa:wght@300..700&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap" rel="stylesheet">
</head>

<body>
    <div class="header" id="top">
        <div class="city">
            <select>
                <option value="city1" style="color: #000;">Город...</option>
                <option value="city2">Москва</option>
                <option value="city3">Вологда</option>
            </select>
        </div>
        <ul class="menu">
            <li class="active"><a href="./index.php">Главная</a></li>
            <li>●</li>
            <li><a href="./news.html">Новости</a></li>
            <li>●</li>
            <li><a href="./portfolio.html">Портфолио</a></li>
            <img src="./images/logo.png" alt="Логотип ОТКРЫТИЕ" class="logo">
            <li><a href="./catalog.html">Каталог</a></li>
            <li>●</li>
            <li><a href="#ind-design">Инд.дизайн</a></li>
            <li>●</li>
            <li><a href="#contacts">Контакты</a></li>
        </ul>
        <div class="phone">
            8-800-555-35-35
        </div>
    </div>

    <div class="offer">
        <div class="content">
            <h1><span class="colored-text">Станьте обладателем</span><br> дверей премиум качества от производителя</h1>
            <p>Входные уличные и межкомнатные двери</p>
            <a href="./catalog.html" class="knopkazak">СДЕЛАТЬ ЗАКАЗ</a>
        </div>
        <div class="columns">
            <div class="column">
                <h2>3 ЭТАПА</h2>
                <h3>Контроля качества</h3>
                <p>Каждая деталь продукции проверяется квалифицированными специалистами</p>
            </div>
            <div class="column">
                <h2>1000+ ДВЕРЕЙ</h2>
                <h3>В каталоге и оффлайн-точках</h3>
                <p>Огромный ассортимент и выбор продукции</p>
            </div>
            <div class="column">
                <h2>24/7</h2>
                <h3>Обратная связь</h3>
                <p>Персональный менеджер на связи с вами</p>
            </div>
        </div>
    </div>
    <div class="collection">
        <div class="container">
            <h1>КАТАЛОГ ИНТЕРЬЕРНЫХ ДВЕРЕЙ</h1>
            <div class="grid">
                <div class="square">
                    <a href="./catalog.html"><img src="./images/1.png"></a>
                </div>
                <div class="square">
                    <div class="text-square">
                        <p>── LIGHTLY ──</p>
                        <div class="hover-text">Классические двери с объемными фрезерованными филенками</div>
                    </div>
                </div>
                <div class="square">
                    <a href="./catalog.html"><img src="./images/2.png"></a>
                </div>
                <div class="square">
                    <div class="text-square">
                        <p>── WOODY ──</p>
                        <div class="hover-text">Многообразие образов за счет комбинации вставок, молдингов и стекол
                        </div>
                    </div>
                </div>
                <div class="square">
                    <div class="text-square">
                        <p>─── AIR ───</p>
                        <div class="hover-text">Традиционные формы с гладкими филенками</div>
                    </div>
                </div>
                <div class="square">
                    <a href="./catalog.html"><img src="./images/3.png"></a>
                </div>
                <div class="square">
                    <div class="text-square">
                        <p>─ DARK ACADEM ─</p>
                        <div class="hover-text">Коллекция в разнонаправленном натуральном шпоне дуба, ореха и эвкалипта
                        </div>
                    </div>
                </div>
                <div class="square">
                    <a href="./catalog.html"><img src="./images/4.png"></a>
                </div>
                <div class="square">
                    <a href="./catalog.html"><img src="./images/5.png"></a>
                </div>
                <div class="square">
                    <div class="text-square">
                        <p>── ROYAL ──</p>
                        <div class="hover-text">Объемные элементы на полотне</div>
                    </div>
                </div>
                <div class="square">
                    <a href="./catalog.html"><img src="./images/6.png"></a>
                </div>
                <div class="square">
                    <div class="text-square">
                        <p>── NATURE ──</p>
                        <div class="hover-text">Классические формы в массиве бука</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="portfolio">
        <div class="container2">
            <h1>РЕАЛИЗОВАННЫЕ ПРОЕКТЫ</h1>
            <div class="grid">
                <div class="square2">
                    <div class="text-square2">
                        <p>ПОРТФОЛИО</p>
                    </div>
                </div>
                <div class="square2">
                    <img src="./images/a.png">
                </div>
                <div class="square2">
                    <img src="./images/b.png">
                </div>
                <div class="square2">
                    <img src="./images/c.png">
                </div>
                <div class="square2">
                    <img src="./images/d.png">
                </div>
                <div class="square2">
                    <img src="./images/e.png">
                </div>
                <div class="square2">
                    <img src="./images/f.png">
                </div>
                <div class="square">
                    <a href="./portfolio.html"><div class="text-square">
                        <p>СМОТРЕТЬ ВСЕ<br> ПРОЕКТЫ</p>
                    </div></a>
                    <div class="arrow top-left horizontal"></div>
                    <div class="arrow top-left vertical"></div>
                    <div class="arrow bottom-right horizontal"></div>
                    <div class="arrow bottom-right vertical"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="citys">
        <h1>САЛОНЫ-БУТИКИ “ОТКРЫТИЕ” В РОССИИ</h1>
        <div class="karta">
            <img src="./images/karta.png" class="map">
        </div>
    </div>
    <div class="zayavka" id="ind-design">
    <h1>ХОТИТЕ ЗАКАЗАТЬ ПРОДУКЦИЮ “ОТКРЫТИЕ”?</h1>
    <form action="index.php" method="POST">
        <div class="row">
            <div class="column">
                <input type="text" placeholder="Ваше имя" class="input" id="name" name="name" required>
                <textarea placeholder="Описание запроса" class="input wide" id="description" name="description" required></textarea>
            </div>
            <div class="column">
                <input type="email" placeholder="Email" class="input" id="email" name="email" required>
            </div>
            <div class="column">
                <input type="tel" placeholder="Номер телефона" class="input" id="phone" name="phone" required>
                <button type="submit" class="button">Отправить</button>
            </div>
        </div>
    </form>
    <div id="myModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <p id="modalMessage">Some text in the Modal..</p>
        </div>
    </div>    
    </div>
    <div class="news">
        <h1>ПОСЛЕДНИЕ НОВОСТИ</h1>
        <div class="news-block">
            <img src="./images/n1.png" alt="Новость 1" class="news-img">
            <div class="news-info">
                <h3>07.05.2024</h3>
                <h2>НОВИНКА ОТ “ОТКРЫТИЕ” - ДВЕРЬ PIANO ENIGMA</h2>
                <p>Компания «Артелле» первой применила раздвижной механизм для алюминиевых
                    дверей с светопрозрачными элементами из стекла. Новинка раздвижная дверь
                    Piano Enigma — новое решение на рынке
                    дверей. За основу новой двери был взят
                    раздвижной механизм MAGIC (Италия). Система МАЮ разработана ведущей
                    итальянской компанией, лидером в области раздвижных систем.
                </p>
            </div>
        </div>

        <div class="news-block">
            <img src="./images/n2.png" alt="Новость 2" class="news-img">
            <div class="news-info">
                <h3>04.04.2024</h3>
                <h2>ООН ОБЪЯВИЛА 2024 ГОД МЕЖДУНАРОДНЫМ ГОДОМ СТЕКЛА</h2>
                <p>ООН объявила 2022 год Международным.
                    годом стекла. В 2022 году под эгидой ООН
                    планируются широкомасштабные
                    торжества в странах Европы и Азии в связи
                    с Международным годом стекла. История
                    насчитывает более 5000 лет. Сфера его
                    применения огромна — от пулестойкого
                    триплекса до декоративных панелей на стены. Компания ОТКРЫТИЕ является
                    производителем элитных дверей.</p>
            </div>
        </div>

        <div class="news-block">
            <img src="./images/n3.png" alt="Новость 3" class="news-img">
            <div class="news-info">
                <h3>28.12.2023</h3>
                <h2>С НАСТУПАЮЩИМ НОВЫМ 2024 ГОДОМ И РОЖДЕСТВОМ!</h2>
                <p>Дорогие Партнеры, Заказчики, коллеги и друзья! Поздравляем вас с наступающим
                    Новым 2024 годом и Рождеством! Пусть весь будущий год будет полон удачи,
                    счастья, добра и ярких, незабываемых
                    моментов! Мира и благополучия вам и вашим близким. Ваша компания ОТКРЫТИЕ!</p>
            </div>
        </div>
        <div class="view-all-news">
            <button onClick="location.href='./news.html';">СМОТРЕТЬ ВСЕ НОВОСТИ</button>
        </div>
    </div>

    <div class="about">
        <h2>О КОМПАНИИ</h2>
        <div class="contentabout">
            <img src="./images/about.png" alt="Изображение" class="image">
            <div class="opisaniekomp">
                <p>Наша компания специализируется на продаже дверей высокого качества различных стилей и дизайнов. Мы
                    стремимся предложить нашим клиентам широкий выбор товаров, которые будут соответствовать всем их
                    потребностям и предпочтениям.
                    <br><br>
                    Мы гордимся тем, что работаем только с проверенными производителями, чьи изделия отличаются
                    превосходным качеством и долговечностью. Наша команда профессиональных специалистов всегда готова
                    помочь вам выбрать идеальную дверь для вашего дома или офиса.
                </p>
                <button class="podr">ПОДРОБНЕЕ</button>
            </div>
        </div>
    </div>

    <footer>
        <div class="logo2">
            <img src="./images/logo.png" alt="Логотип">
            <p>Открытие.<br>
                Все права защищены 2020-2024.</p>
        </div>


        <div class="menu2">
            <a href="./index.php" class="active">Главная</a>
            <a href="./news.html">Новости</a>
            <a href="./portfolio.html">Портфолио</a>
            <a href="./catalog.html">Каталог</a>
            <a href="#ind-design">Инд.дизайн</a>
            <a href="#contacts">Контакты</a>
        </div>

        <div class="contact-info" id="contacts">
            <div>
                <p>Вологодская область, г. Вологда<br> ул. Мебельная д. 44</p>
                <p class="phone2">8-800-555-35-35</p>
                <p class="email">info@opendoors.com</p>
                <img src="./images/vk.png" alt="Иконка соц.сети" class="social-icon">
                <p style="text-decoration: underline;">Политика конфиденциальности</p>
            </div>
        </div>
        <div class="scroll-to-top">
        <a href="#top">
            <img src="./images/arrup.png" alt="Наверх">
        </a>
        </div>
    </footer>
    
    <script>
    // Получение модального окна и элементов в нем
    var modal = document.getElementById("myModal");
    var span = document.getElementsByClassName("close")[0];

    // Когда пользователь нажимает на [x], закрыть модальное окно
    span.onclick = function() {
        modal.style.display = "none";
    }

    // Когда пользователь нажимает в любое место вне модального окна, закрыть его
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
    
    // Функция для отображения модального окна с сообщением
    function showModal(message) {
        document.getElementById("modalMessage").innerText = message;
        modal.style.display = "block";
    }
    </script>


    <?php
    $displayModal = false;
    $modalMessage = '';

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $servername = "localhost";
        $username = "milmil";
        $password = "marselin1600";
        $dbname = "form";

        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        function test_input($data) {
            return htmlspecialchars(stripslashes(trim($data)));
        }

        $name = test_input($_POST['name']);
        $phone = test_input($_POST['phone']);
        $email = test_input($_POST['email']);
        $description = test_input($_POST['description']);

        if (empty($name) || empty($phone) || empty($email) || empty($description)) {
            $displayModal = true;
            $modalMessage = 'Все поля обязательны для заполнения.';
        } else {
            $sql = "INSERT INTO zayavka (name, phone, email, description) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);

            if ($stmt === false) {
                $displayModal = true;
                $modalMessage = 'Ошибка подготовки запроса: ' . $conn->error;
            } else {
                $stmt->bind_param("ssss", $name, $phone, $email, $description);

                if ($stmt->execute() === TRUE) {
                    $displayModal = true;
                    $modalMessage = 'Заявка успешно отправлена! В ближайшее время с Вами свяжется наш менеджер :)';
                } else {
                    $displayModal = true;
                    $modalMessage = 'Ошибка: ' . $stmt->error;
                }
                $stmt->close();
            }
        }

        $conn->close();
    }
    ?>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script>
        var modal = document.getElementById("myModal");
        var span = document.getElementsByClassName("close")[0];

        span.onclick = function() {
            modal.style.display = "none";
        }

        
        window.onclick = function(event) {
            if (event.target === modal) {
                modal.style.display = "none";
            }
        }
        
        function showModal(message) {
            document.getElementById("modalMessage").innerText = message;
            modal.style.display = "block";
        }

        <?php if ($displayModal): ?>
            document.addEventListener("DOMContentLoaded", function() {
                showModal('<?php echo $modalMessage; ?>');
            });
        <?php endif; ?>
    </script>
</body>

</html>
