<?php
    $mysqli = new mysqli ("localhost", "milmil", "marselin1600", "form");
    $mysqli -> query("SET NAMES 'utf8'");
?>
